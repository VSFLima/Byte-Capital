
-- Create coins table with auto-incrementing ID
CREATE TABLE public.coins (
  id SERIAL PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  image_url TEXT,
  profit_loss NUMERIC DEFAULT 10,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Add profit_loss column (if not exists from initial creation)
ALTER TABLE public.coins 
ADD COLUMN IF NOT EXISTS profit_loss NUMERIC DEFAULT 10;

-- Insert sample coin data
INSERT INTO public.coins (symbol, image_url, profit_loss, status) VALUES
('BTC', 'https://i.ibb.co/vdtQGJQ/1711137174306-Bitcoin-svg.png', 10, 'active'),
('ETH', 'https://i.ibb.co/GVY5981/1711137435289-63f5ae36e64321677045302.png', 12, 'active'),
('BNB', 'https://i.ibb.co/zmSk16z/1711137454561-63f5aefe3d51d1677045502.png', 8, 'active')
ON CONFLICT (symbol) DO NOTHING;

-- Enable Row Level Security
ALTER TABLE public.coins ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Public read access" 
  ON public.coins 
  FOR SELECT 
  USING (true);

-- Update existing records to ensure profit_loss values are properly set as percentages
UPDATE public.coins 
SET profit_loss = CASE 
    WHEN profit_loss IS NULL THEN 10
    WHEN profit_loss = 0 THEN 10
    ELSE ABS(profit_loss)
END
WHERE profit_loss IS NULL OR profit_loss = 0;

-- Add comment to explain the profit_loss column
COMMENT ON COLUMN public.coins.profit_loss IS 'The profit/loss percentage for trades on this coin';

-- Create index for better performance on symbol lookups
CREATE INDEX IF NOT EXISTS idx_coins_symbol ON public.coins(symbol);
CREATE INDEX IF NOT EXISTS idx_coins_status ON public.coins(status);
