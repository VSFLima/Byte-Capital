
-- Complete database schema with all tables, data, functions, and rules
-- This includes all the functionality from the TradeBull application

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create custom types
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create utility function for updating timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create users table (custom authentication)
CREATE TABLE public.users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT,
  pay_id TEXT UNIQUE,
  balance NUMERIC NOT NULL DEFAULT 0.00,
  bot_balance NUMERIC NOT NULL DEFAULT 0.00,
  withdraw_pin TEXT,
  referred_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
  referral_code TEXT UNIQUE,
  total_referrals INTEGER DEFAULT 0,
  referral_earnings NUMERIC DEFAULT 0.00,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create admin users table
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT,
  email TEXT,
  role TEXT NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create site settings table
CREATE TABLE public.site_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  site_title TEXT NOT NULL DEFAULT 'TradeBull',
  site_currency TEXT NOT NULL DEFAULT 'USDT',
  currency_symbol TEXT NOT NULL DEFAULT '$',
  signup_bonus NUMERIC NOT NULL DEFAULT 5,
  transfer_min_limit NUMERIC NOT NULL DEFAULT 10,
  transfer_charge NUMERIC NOT NULL DEFAULT 3,
  imgbb_api_key TEXT,
  refer_need INTEGER NOT NULL DEFAULT 0,
  email_verification BOOLEAN NOT NULL DEFAULT true,
  kyc_verification BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create app settings table
CREATE TABLE public.app_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  app_name TEXT DEFAULT 'TradeBull',
  app_description TEXT DEFAULT 'Trading & Investing',
  app_logo_url TEXT DEFAULT 'https://tradebull.scriptbasket.com/logo/logo.png',
  app_rating DECIMAL(2,1) DEFAULT 4.6,
  app_reviews_count TEXT DEFAULT '5,000+',
  app_downloads_count TEXT DEFAULT '156K+',
  app_download_url TEXT DEFAULT '/app/app.apk',
  app_screenshots TEXT[] DEFAULT ARRAY[
    'https://tradebull.scriptbasket.com/app/screenshots/1.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/2.webp', 
    'https://tradebull.scriptbasket.com/app/screenshots/3.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/4.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/5.webp'
  ],
  app_about TEXT DEFAULT 'It''s a social platform for traders and investors to share their ideas, discuss markets, and follow each other''s trading activities.',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create coins table
CREATE TABLE public.coins (
  id SERIAL PRIMARY KEY,
  symbol TEXT NOT NULL,
  image_url TEXT,
  profit_loss NUMERIC DEFAULT 10,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create deposit methods table
CREATE TABLE public.deposit_methods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  currency TEXT NOT NULL,
  image_url TEXT NOT NULL,
  symbol TEXT NOT NULL DEFAULT '$',
  status TEXT NOT NULL DEFAULT 'active',
  order_priority INTEGER NOT NULL DEFAULT 0,
  min_amount NUMERIC DEFAULT 0,
  max_amount NUMERIC DEFAULT 999999999,
  deposit_address TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create withdraw methods table
CREATE TABLE public.withdraw_methods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  currency TEXT NOT NULL,
  image_url TEXT NOT NULL,
  symbol TEXT NOT NULL DEFAULT '$',
  exchange_rate NUMERIC NOT NULL DEFAULT 1,
  charge_percentage NUMERIC NOT NULL DEFAULT 0,
  user_info_label TEXT NOT NULL DEFAULT 'Your Account Details',
  status TEXT NOT NULL DEFAULT 'active',
  order_priority INTEGER NOT NULL DEFAULT 0,
  min_amount NUMERIC DEFAULT 0,
  max_amount NUMERIC DEFAULT 999999999,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create deposits table
CREATE TABLE public.deposits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  deposit_method_id UUID REFERENCES public.deposit_methods(id),
  amount NUMERIC NOT NULL,
  transaction_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create withdrawals table
CREATE TABLE public.withdrawals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  withdraw_method_id UUID REFERENCES public.withdraw_methods(id),
  amount NUMERIC NOT NULL,
  payment_address TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create transactions table
CREATE TABLE public.transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  type TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reference_id UUID,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create trade transactions table
CREATE TABLE public.trade_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  symbol TEXT NOT NULL,
  trade_type TEXT NOT NULL,
  action TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  price NUMERIC NOT NULL,
  buy_price NUMERIC,
  close_price NUMERIC DEFAULT NULL,
  trade_close_price NUMERIC DEFAULT 0,
  profit_loss NUMERIC DEFAULT 2,
  status TEXT NOT NULL DEFAULT 'pending',
  trade_status TEXT DEFAULT 'PENDING',
  win_loss TEXT DEFAULT 'pending',
  closing_time TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  return_time TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create banners table
CREATE TABLE public.banners (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create contact details table
CREATE TABLE public.contact_details (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  link TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create notice settings table
CREATE TABLE public.notice_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  scrolling_notice TEXT NOT NULL DEFAULT 'TradeBull - It''s a Option Trading App.',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create daily checkin settings table
CREATE TABLE public.daily_checkin_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  day_name TEXT NOT NULL UNIQUE,
  bonus_amount NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user checkins table
CREATE TABLE public.user_checkins (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  checkin_date DATE NOT NULL DEFAULT CURRENT_DATE,
  day_name TEXT NOT NULL,
  bonus_amount NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, checkin_date)
);

-- Create referral settings table
CREATE TABLE public.referral_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_type TEXT NOT NULL,
  level_number INTEGER NOT NULL,
  bonus_percentage NUMERIC NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(setting_type, level_number)
);

-- Create NFTs table
CREATE TABLE public.nfts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  image_url TEXT,
  min_invest_limit NUMERIC NOT NULL DEFAULT 0,
  max_invest_limit NUMERIC NOT NULL DEFAULT 0,
  min_profit_percentage NUMERIC NOT NULL DEFAULT 0,
  max_profit_percentage NUMERIC NOT NULL DEFAULT 0,
  nft_date TEXT,
  validity_days INTEGER NOT NULL DEFAULT 0,
  website_link TEXT,
  details TEXT,
  is_verified BOOLEAN NOT NULL DEFAULT true,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create NFT transactions table
CREATE TABLE public.nft_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  nft_id UUID NOT NULL REFERENCES public.nfts(id) ON DELETE CASCADE,
  investment_amount NUMERIC NOT NULL,
  return_amount NUMERIC NOT NULL DEFAULT 0,
  latest_return_amount NUMERIC NOT NULL DEFAULT 0,
  return_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  invested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  next_return_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create trade settings table
CREATE TABLE public.trade_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  manual_min_trade_amount NUMERIC NOT NULL DEFAULT 5,
  manual_max_trade_amount NUMERIC NOT NULL DEFAULT 100,
  manual_daily_trade_limit INTEGER NOT NULL DEFAULT 100,
  bot_profit_type TEXT NOT NULL DEFAULT 'profit' CHECK (bot_profit_type IN ('profit', 'lose')),
  bot_min_trade_amount NUMERIC NOT NULL DEFAULT 10,
  bot_max_trade_amount NUMERIC NOT NULL DEFAULT 200,
  bot_daily_trade_limit INTEGER NOT NULL DEFAULT 5,
  time_profit_settings JSONB NOT NULL DEFAULT '[
    {"time_hours": 1, "profit_percentage": 2},
    {"time_hours": 3, "profit_percentage": 5},
    {"time_hours": 6, "profit_percentage": 10},
    {"time_hours": 12, "profit_percentage": 15},
    {"time_hours": 24, "profit_percentage": 20}
  ]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create bot tokens table
CREATE TABLE public.bot_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user bot trades table
CREATE TABLE public.user_bot_trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  trade_timer INTEGER NOT NULL DEFAULT 1,
  profit_or_lose TEXT DEFAULT 'profit',
  profit_percent NUMERIC DEFAULT 0,
  profit NUMERIC DEFAULT 0,
  coins TEXT[] DEFAULT '{}',
  invest_amount NUMERIC DEFAULT 0,
  return_amount NUMERIC DEFAULT 0,
  profit_loss NUMERIC DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  open_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  close_time TIMESTAMP WITH TIME ZONE,
  return_time TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_users_username ON public.users(username);
CREATE INDEX idx_users_referral_code ON public.users(referral_code);
CREATE INDEX idx_admin_users_username ON public.admin_users(username);
CREATE INDEX idx_deposits_user_id ON public.deposits(user_id);
CREATE INDEX idx_deposits_status ON public.deposits(status);
CREATE INDEX idx_withdrawals_user_id ON public.withdrawals(user_id);
CREATE INDEX idx_withdrawals_status ON public.withdrawals(status);
CREATE INDEX idx_transactions_user_id ON public.transactions(user_id);
CREATE INDEX idx_transactions_type ON public.transactions(type);
CREATE INDEX idx_trade_transactions_user_id ON public.trade_transactions(user_id);
CREATE INDEX idx_trade_transactions_status ON public.trade_transactions(status);
CREATE INDEX idx_trade_transactions_user_symbol ON public.trade_transactions(user_id, symbol);
CREATE INDEX idx_trade_transactions_trade_status ON public.trade_transactions(trade_status);
CREATE INDEX idx_trade_transactions_closing_time ON public.trade_transactions(closing_time);
CREATE INDEX idx_user_checkins_user_id_date ON public.user_checkins(user_id, checkin_date);
CREATE INDEX idx_nft_transactions_user_id ON public.nft_transactions(user_id);
CREATE INDEX idx_nft_transactions_nft_id ON public.nft_transactions(nft_id);
CREATE INDEX idx_nft_transactions_status ON public.nft_transactions(status);
CREATE INDEX idx_nft_transactions_expires_at ON public.nft_transactions(expires_at);

-- Create functions
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT 
LANGUAGE plpgsql 
AS $$
DECLARE
    code TEXT;
    exists_check BOOLEAN;
    random_string TEXT;
BEGIN
    LOOP
        random_string := substring(md5(random()::text) from 1 for 6);
        code := encode(random_string::bytea, 'base64');
        code := replace(replace(code, '+', '-'), '/', '_');
        code := rtrim(code, '=');
        
        SELECT EXISTS(SELECT 1 FROM public.users WHERE referral_code = code) INTO exists_check;
        
        IF NOT exists_check THEN
            EXIT;
        END IF;
    END LOOP;
    
    RETURN code;
END;
$$;

CREATE OR REPLACE FUNCTION public.auto_generate_referral_code()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.referral_code IS NULL THEN
        NEW.referral_code := generate_referral_code();
    END IF;
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    signup_bonus_amount NUMERIC;
BEGIN
    SELECT COALESCE(signup_bonus, 5) INTO signup_bonus_amount 
    FROM public.site_settings 
    LIMIT 1;
    
    UPDATE public.users 
    SET balance = balance + signup_bonus_amount,
        updated_at = now()
    WHERE id = NEW.id;
    
    INSERT INTO public.transactions (
        user_id, 
        type, 
        amount, 
        description, 
        status
    ) VALUES (
        NEW.id,
        'signup_bonus',
        signup_bonus_amount,
        'Welcome signup bonus',
        'completed'
    );
    
    IF NEW.referred_by IS NOT NULL THEN
        UPDATE public.users 
        SET 
            total_referrals = total_referrals + 1,
            updated_at = now()
        WHERE id = NEW.referred_by;
    END IF;
    
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_deposit_referral_commission(deposit_user_id uuid, deposit_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    current_referrer_id uuid;
    current_level integer := 1;
    commission_percentage numeric;
    commission_amount numeric;
    level_setting RECORD;
BEGIN
    SELECT referred_by INTO current_referrer_id
    FROM public.users 
    WHERE id = deposit_user_id;
    
    WHILE current_referrer_id IS NOT NULL AND current_level <= 15 LOOP
        SELECT * INTO level_setting
        FROM public.referral_settings 
        WHERE setting_type = 'deposit' 
        AND level_number = current_level 
        AND active = true;
        
        IF level_setting.id IS NOT NULL AND level_setting.bonus_percentage > 0 THEN
            commission_percentage := level_setting.bonus_percentage;
            commission_amount := (deposit_amount * commission_percentage) / 100;
            
            UPDATE public.users 
            SET 
                balance = balance + commission_amount,
                referral_earnings = referral_earnings + commission_amount,
                updated_at = now()
            WHERE id = current_referrer_id;
            
            INSERT INTO public.transactions (
                user_id, 
                type, 
                amount, 
                description, 
                status
            ) VALUES (
                current_referrer_id,
                'commission',
                commission_amount,
                'Level ' || current_level || ' deposit referral commission (' || commission_percentage || '%)',
                'completed'
            );
        END IF;
        
        SELECT referred_by INTO current_referrer_id
        FROM public.users 
        WHERE id = current_referrer_id;
        
        current_level := current_level + 1;
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.approve_deposit_and_process_referrals()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF OLD.status != NEW.status AND (NEW.status = 'complete' OR NEW.status = 'approved') THEN
        UPDATE public.users 
        SET 
            balance = balance + NEW.amount,
            updated_at = now()
        WHERE id = NEW.user_id;
        
        INSERT INTO public.transactions (
            user_id, 
            type, 
            amount, 
            description, 
            status,
            reference_id
        ) VALUES (
            NEW.user_id,
            'deposit',
            NEW.amount,
            'Deposit approved - Transaction ID: ' || NEW.transaction_id,
            'completed',
            NEW.id
        );
        
        PERFORM public.handle_deposit_referral_commission(NEW.user_id, NEW.amount);
    END IF;
    
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_trade_win_referral_commission(winning_user_id uuid, trade_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    current_referrer_id uuid;
    current_level integer := 1;
    commission_percentage numeric;
    commission_amount numeric;
    level_setting RECORD;
BEGIN
    SELECT referred_by INTO current_referrer_id
    FROM public.users 
    WHERE id = winning_user_id;
    
    WHILE current_referrer_id IS NOT NULL AND current_level <= 15 LOOP
        SELECT * INTO level_setting
        FROM public.referral_settings 
        WHERE setting_type = 'trade_win' 
        AND level_number = current_level 
        AND active = true;
        
        IF level_setting.id IS NOT NULL AND level_setting.bonus_percentage > 0 THEN
            commission_percentage := level_setting.bonus_percentage;
            commission_amount := (trade_amount * commission_percentage) / 100;
            
            UPDATE public.users 
            SET 
                balance = balance + commission_amount,
                referral_earnings = referral_earnings + commission_amount,
                updated_at = now()
            WHERE id = current_referrer_id;
            
            INSERT INTO public.transactions (
                user_id, 
                type, 
                amount, 
                description, 
                status
            ) VALUES (
                current_referrer_id,
                'commission',
                commission_amount,
                'Level ' || current_level || ' trade win referral commission (' || commission_percentage || '%)',
                'completed'
            );
        END IF;
        
        SELECT referred_by INTO current_referrer_id
        FROM public.users 
        WHERE id = current_referrer_id;
        
        current_level := current_level + 1;
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.process_nft_returns()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    investment_record RECORD;
    profit_amount NUMERIC;
    new_next_return_at TIMESTAMP WITH TIME ZONE;
BEGIN
    FOR investment_record IN 
        SELECT nt.*, n.min_profit_percentage, n.max_profit_percentage, n.validity_days
        FROM public.nft_transactions nt
        JOIN public.nfts n ON nt.nft_id = n.id
        WHERE nt.status = 'active' 
        AND nt.next_return_at IS NOT NULL 
        AND nt.next_return_at <= NOW()
        AND nt.expires_at > NOW()
    LOOP
        profit_amount := investment_record.investment_amount * 
            (investment_record.min_profit_percentage + 
             (random() * (investment_record.max_profit_percentage - investment_record.min_profit_percentage))) / 100;
        
        UPDATE public.users 
        SET balance = balance + profit_amount,
            updated_at = now()
        WHERE id = investment_record.user_id;
        
        INSERT INTO public.transactions (
            user_id, 
            type, 
            amount, 
            description, 
            status
        ) VALUES (
            investment_record.user_id,
            'nft_return',
            profit_amount,
            'NFT Return - ' || (SELECT title FROM public.nfts WHERE id = investment_record.nft_id),
            'completed'
        );
        
        new_next_return_at := NOW() + INTERVAL '24 hours';
        
        IF new_next_return_at >= investment_record.expires_at THEN
            new_next_return_at := NULL;
        END IF;
        
        UPDATE public.nft_transactions
        SET 
            latest_return_amount = profit_amount,
            return_amount = return_amount + profit_amount,
            return_count = return_count + 1,
            next_return_at = new_next_return_at,
            status = CASE 
                WHEN new_next_return_at IS NULL THEN 'completed'
                ELSE 'active'
            END,
            updated_at = now()
        WHERE id = investment_record.id;
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.set_initial_nft_return_time()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.next_return_at := NEW.invested_at + INTERVAL '24 hours';
    
    IF NEW.next_return_at >= NEW.expires_at THEN
        NEW.next_return_at := NULL;
    END IF;
    
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.deduct_user_balance(user_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.users 
    SET balance = balance - amount,
        updated_at = now()
    WHERE id = user_id AND balance >= amount;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Insufficient balance or user not found';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.add_user_balance(user_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.users 
    SET balance = balance + amount,
        updated_at = now()
    WHERE id = user_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'User not found';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_server_time()
RETURNS timestamp with time zone
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN NOW();
END;
$$;

-- Create triggers
CREATE TRIGGER trigger_auto_generate_referral_code
    BEFORE INSERT ON public.users
    FOR EACH ROW
    EXECUTE FUNCTION auto_generate_referral_code();

CREATE TRIGGER on_user_created
    AFTER INSERT ON public.users
    FOR EACH ROW 
    EXECUTE FUNCTION public.handle_new_user_signup();

CREATE TRIGGER on_deposit_status_change
    AFTER UPDATE ON public.deposits
    FOR EACH ROW 
    EXECUTE FUNCTION public.approve_deposit_and_process_referrals();

CREATE TRIGGER set_nft_return_time
    BEFORE INSERT ON public.nft_transactions
    FOR EACH ROW
    EXECUTE FUNCTION public.set_initial_nft_return_time();

-- Create updated_at triggers for all tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_admin_users_updated_at BEFORE UPDATE ON public.admin_users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_app_settings_updated_at BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_deposit_methods_updated_at BEFORE UPDATE ON public.deposit_methods FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_withdraw_methods_updated_at BEFORE UPDATE ON public.withdraw_methods FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_deposits_updated_at BEFORE UPDATE ON public.deposits FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_withdrawals_updated_at BEFORE UPDATE ON public.withdrawals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_trade_transactions_updated_at BEFORE UPDATE ON public.trade_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_banners_updated_at BEFORE UPDATE ON public.banners FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contact_details_updated_at BEFORE UPDATE ON public.contact_details FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_notice_settings_updated_at BEFORE UPDATE ON public.notice_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_daily_checkin_settings_updated_at BEFORE UPDATE ON public.daily_checkin_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_referral_settings_updated_at BEFORE UPDATE ON public.referral_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_nfts_updated_at BEFORE UPDATE ON public.nfts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_nft_transactions_updated_at BEFORE UPDATE ON public.nft_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_trade_settings_updated_at BEFORE UPDATE ON public.trade_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bot_tokens_updated_at BEFORE UPDATE ON public.bot_tokens FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_bot_trades_updated_at BEFORE UPDATE ON public.user_bot_trades FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Disable RLS for custom auth tables
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.deposits DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.nft_transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_details DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notice_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_checkin_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.bot_tokens DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_bot_trades DISABLE ROW LEVEL SECURITY;

-- Enable RLS for public tables
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deposit_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdraw_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nfts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trade_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trade_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_checkins ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Admin can manage banners" ON public.banners FOR ALL USING (true);
CREATE POLICY "Public read access" ON public.coins FOR SELECT USING (true);
CREATE POLICY "Anyone can view deposit methods" ON public.deposit_methods FOR SELECT USING (true);
CREATE POLICY "Admins can manage deposit methods" ON public.deposit_methods FOR ALL USING (true);
CREATE POLICY "Anyone can view withdraw methods" ON public.withdraw_methods FOR SELECT USING (true);
CREATE POLICY "Public read access to NFTs" ON public.nfts FOR SELECT USING (true);
CREATE POLICY "Admin full access to NFTs" ON public.nfts FOR ALL USING (true);
CREATE POLICY "Public read access to trade settings" ON public.trade_settings FOR SELECT USING (true);
CREATE POLICY "Admin full access to trade settings" ON public.trade_settings FOR ALL USING (true);
CREATE POLICY "Allow all trade transactions" ON public.trade_transactions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow user checkins management" ON public.user_checkins FOR ALL USING (true);

-- Enable realtime for specific tables
ALTER TABLE public.transactions REPLICA IDENTITY FULL;
ALTER TABLE public.coins REPLICA IDENTITY FULL;
ALTER TABLE public.trade_transactions REPLICA IDENTITY FULL;

ALTER PUBLICATION supabase_realtime ADD TABLE public.transactions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.coins;
ALTER PUBLICATION supabase_realtime ADD TABLE public.trade_transactions;

-- Insert default data
INSERT INTO public.admin_users (username, password_hash, full_name, email, role)
VALUES ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Administrator', 'admin@tradebull.com', 'admin');

INSERT INTO public.site_settings (
  site_title, site_currency, currency_symbol, signup_bonus, 
  transfer_min_limit, transfer_charge, refer_need, email_verification, kyc_verification
) VALUES (
  'TradeBull', 'USDT', '$', 5, 10, 3, 0, true, true
);

INSERT INTO public.app_settings (app_name, app_description, app_logo_url, app_rating, app_reviews_count, app_downloads_count, app_download_url, app_screenshots, app_about)
VALUES (
  'TradeBull', 
  'Trading & Investing', 
  'https://tradebull.scriptbasket.com/logo/logo.png', 
  4.6, 
  '5,000+', 
  '156K+', 
  '/app/app.apk',
  ARRAY[
    'https://tradebull.scriptbasket.com/app/screenshots/1.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/2.webp', 
    'https://tradebull.scriptbasket.com/app/screenshots/3.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/4.webp',
    'https://tradebull.scriptbasket.com/app/screenshots/5.webp'
  ],
  'It''s a social platform for traders and investors to share their ideas, discuss markets, and follow each other''s trading activities.'
);

INSERT INTO public.coins (symbol, image_url, profit_loss, status) VALUES
('BTC', 'https://i.ibb.co/vdtQGJQ/1711137174306-Bitcoin-svg.png', 10, 'active'),
('ETH', 'https://i.ibb.co/GVY5981/1711137435289-63f5ae36e64321677045302.png', 12, 'active'),
('BNB', 'https://i.ibb.co/zmSk16z/1711137454561-63f5aefe3d51d1677045502.png', 8, 'active');

INSERT INTO public.deposit_methods (name, currency, image_url, symbol, min_amount, max_amount, deposit_address, order_priority) VALUES
('Nagad', 'Taka', 'https://i.ibb.co/dtKh38Y/images.png', '৳', 5, 500, '01712345678', 1),
('bKash', 'Taka', 'https://i.ibb.co/87CCnW3/5e6ab3fa58a91.png', '৳', 5, 500, '01987654321', 2),
('USDT (TRC 20)', 'USDT', 'https://i.ibb.co/dkbyxQM/tether-usdt-badge-crypto-isolated-on-white-background-blockchain-technology-3d-rendering-free-png.webp', '$', 5, 1000, 'TAjQiD4J3xJbNAaEbE3EvcuvSygXgM4rA5', 3);

INSERT INTO public.withdraw_methods (name, currency, image_url, symbol, exchange_rate, charge_percentage, user_info_label, order_priority) VALUES
('Nagad', 'Taka', 'https://i.ibb.co/dtKh38Y/images.png', '৳', 100, 5, 'Your Nagad Personal Number', 1),
('bKash', 'Taka', 'https://i.ibb.co/87CCnW3/5e6ab3fa58a91.png', '৳', 100, 5, 'Your bKash Personal Number', 2),
('USDT (TRC 20)', 'USDT', 'https://i.ibb.co/dkbyxQM/tether-usdt-badge-crypto-isolated-on-white-background-blockchain-technology-3d-rendering-free-png.webp', '$', 1, 2.5, 'Your USDT (TRC 20) Address', 3);

INSERT INTO public.contact_details (name, link) VALUES
('Telegram', 'https://t.me/'),
('Telegram Group', 'https://t.me/'),
('Whatsapp', 'https://wa.me/1234567890');

INSERT INTO public.notice_settings (scrolling_notice) VALUES
('TradeBull - It''s a Option Trading App.');

INSERT INTO public.daily_checkin_settings (day_name, bonus_amount) VALUES
('Saturday', 0.01),
('Sunday', 0.02),
('Monday', 0.03),
('Tuesday', 0.04),
('Wednesday', 0.05),
('Thursday', 0.06),
('Friday', 0.07);

INSERT INTO public.referral_settings (setting_type, level_number, bonus_percentage) VALUES
('deposit', 1, 0), ('deposit', 2, 0), ('deposit', 3, 0), ('deposit', 4, 0), ('deposit', 5, 0),
('deposit', 6, 0), ('deposit', 7, 0), ('deposit', 8, 0), ('deposit', 9, 0), ('deposit', 10, 0),
('deposit', 11, 0), ('deposit', 12, 0), ('deposit', 13, 0), ('deposit', 14, 0), ('deposit', 15, 0),
('trade_win', 1, 20), ('trade_win', 2, 15), ('trade_win', 3, 10), ('trade_win', 4, 5), ('trade_win', 5, 5),
('trade_win', 6, 0), ('trade_win', 7, 0), ('trade_win', 8, 0), ('trade_win', 9, 0), ('trade_win', 10, 0),
('trade_win', 11, 0), ('trade_win', 12, 0), ('trade_win', 13, 0), ('trade_win', 14, 0), ('trade_win', 15, 0);

INSERT INTO public.trade_settings (
  manual_min_trade_amount, manual_max_trade_amount, manual_daily_trade_limit,
  bot_profit_type, bot_min_trade_amount, bot_max_trade_amount, bot_daily_trade_limit,
  time_profit_settings
) VALUES (
  5, 100, 100, 'profit', 10, 200, 5,
  '[
    {"time_hours": 1, "profit_percentage": 2},
    {"time_hours": 3, "profit_percentage": 5},
    {"time_hours": 6, "profit_percentage": 10},
    {"time_hours": 12, "profit_percentage": 15},
    {"time_hours": 24, "profit_percentage": 20}
  ]'::jsonb
);

INSERT INTO public.bot_tokens (symbol, name, image_url) VALUES
('BTC', 'Bitcoin', 'https://i.ibb.co/vdtQGJQ/1711137174306-Bitcoin-svg.png'),
('SOL', 'Solana', 'https://i.ibb.co/0YQJhzM/1711137080552-63f5b15b321561677046107.png'),
('TRX', 'TRON', 'https://i.ibb.co/VBBTjgM/1711137127040-63f5b1ee31d5b1677046254.png'),
('ETH', 'Ethereum', 'https://i.ibb.co/GVY5981/1711137435289-63f5ae36e64321677045302.png'),
('BNB', 'BNB', 'https://i.ibb.co/zmSk16z/1711137454561-63f5aefe3d51d1677045502.png'),
('XRP', 'XRP', 'https://i.ibb.co/K2qkxx4/1711137626248-63f5b06b27ce61677045867.png'),
('ADA', 'Cardano', 'https://i.ibb.co/GVZD7tC/1711137740064-63f5b09e9f94e1677045918.png'),
('DOGE', 'Dogecoin', 'https://i.ibb.co/xqmnGMh/1711137870591-63f5b131cee801677046065.jpg'),
('NEAR', 'NEAR Protocol', 'https://i.ibb.co/KyPDwwM/1711139510495-6535.png'),
('LINK', 'Chainlink', 'https://i.ibb.co/48NtVW0/1711138140032-65b276149bdac1706194452.png'),
('LTC', 'Litecoin', 'https://i.ibb.co/vZDT3t6/1711138170595-64b0737bcd6471689285499.jpg'),
('ALGO', 'Algorand', 'https://i.ibb.co/JBx1w9x/1711138271497-65b274eeea94b1706194158.png'),
('APT', 'Aptos', 'https://i.ibb.co/SfMKk5K/1711138580329-21794.png'),
('STX', 'Stacks', 'https://i.ibb.co/hdSTNkp/1711139575059-4847.png'),
('ATOM', 'Cosmos', 'https://i.ibb.co/88Thdwf/1711138693569-3794.png'),
('GALA', 'Gala', 'https://i.ibb.co/kQThwds/1711138741502-7080.png'),
('ICP', 'Internet Computer', 'https://i.ibb.co/qDzm0xR/1711139481440-8916.png'),
('GMT', 'STEPN', 'https://i.ibb.co/cx8MVYF/1711138891908-18069.png'),
('BCH', 'Bitcoin Cash', 'https://i.ibb.co/x33zq5k/1711139389480-1831.png'),
('AVAX', 'Avalanche', 'https://i.ibb.co/W07JwvF/1711139227465-5805.png'),
('ARB', 'Arbitrum', 'https://i.ibb.co/Tv2xV5M/1711139634049-11841.png'),
('AAVE', 'Aave', 'https://i.ibb.co/8cnJshV/1711139761164-7278.png'),
('XMR', 'Monero', 'https://i.ibb.co/x6tQWqH/1711139789384-328.png'),
('ENS', 'ENS', 'https://i.ibb.co/tQTgxPd/13855.png'),
('DOT', 'Polkadot', 'https://i.ibb.co/MMZSLWT/Polkadot-Logo-Animation-64x64.gif'),
('AR', 'Arweave', 'https://i.ibb.co/68HYdPs/5632.png'),
('XLM', 'Stellar', 'https://i.ibb.co/B2q6bKh/512.png'),
('S', 'Sonic', 'https://i.ibb.co.com/b5s7SXjJ/32684.png'),
('BNX', 'BinaryX', 'https://i.ibb.co/yQHshML/23635.png'),
('NTRN', 'Neutron', 'https://i.ibb.co/PQ5rds6/26680.png'),
('QNT', 'Quant', 'https://i.ibb.co/MVymyvM/3155.png'),
('AXL', 'Axelar', 'https://i.ibb.co/VmqS7Q0/17799.png'),
('DASH', 'Dash', 'https://i.ibb.co/KDt7SSL/131.png'),
('DEXE', 'DeXe', 'https://i.ibb.co/fNczhgr/7326.png');

-- Setup cron jobs for automated tasks
SELECT cron.schedule(
  'auto-close-expired-trades',
  '* * * * *',
  $$
  SELECT
    net.http_post(
        url:='https://xqqffgrnfrqtcleibhoy.supabase.co/functions/v1/auto-close-trades',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxcWZmZ3JuZnJxdGNsZWliaG95Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI3NDU1ODAsImV4cCI6MjA2ODMyMTU4MH0.8cSskn4TXESQZVqKxpZM_Q7KCUM82BayV5Jhep_0i7A"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);

SELECT cron.schedule(
    'process-nft-returns-hourly',
    '0 * * * *',
    $$
    SELECT public.process_nft_returns();
    $$
);
